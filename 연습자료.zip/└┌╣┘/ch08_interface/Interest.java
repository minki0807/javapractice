package ch08_interface;

public interface Interest {
    void addInterest(); // 이자 계산 메서드
}
