package ch12;

public class TraditionalExample {
    public static void main(String[] args) {
    //    EvenCheck even = new EvenCheck(); // 객체 생성
    //    System.out.println(even.isEven(15)); // 생성한 객체로 isEven() 메서드 호출
    }
}
