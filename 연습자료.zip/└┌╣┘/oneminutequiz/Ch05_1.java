package oneminutequiz;

public class Ch05_1 {
    public static void main(String[] args) {
        for (int i = 1; i <= 100; i++) {
            int sum = 0;
            sum = sum + i;
        }
        //System.out.println(sum);
    }
}
