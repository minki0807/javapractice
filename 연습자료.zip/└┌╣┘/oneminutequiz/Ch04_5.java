package oneminutequiz;

public class Ch04_5 {
    public static void main(String[] args) {
        int input = 1;
        switch(input){
            case (1):
                System.out.print("1");
            case (2):
                System.out.print("2");
            case (3):
                System.out.print("3");
        }
    }
}
