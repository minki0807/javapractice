package oneminutequiz;

public class Ch03 {
    public static void main(String[] args) {
        // 2번
        int intValue = 123;
        double doubleValue = 456.789;
        // 정수와 실수 출력
        System.out.printf("정수: %d\n", intValue);
        System.out.printf("실수: %.04f\n", doubleValue);
        // 5번
        int a = 1;
        char b = '1';
        int c = a + b;
        System.out.println(c);

    }

}
