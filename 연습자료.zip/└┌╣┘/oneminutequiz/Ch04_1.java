package oneminutequiz;

import java.util.Scanner;

public class Ch04_1 {
    public static void main(String[] args) {
        int score = 60;
        if (score > 60)  {
            System.out.println("합격입니다.");
        } else  {
            System.out.println("불합격입니다. 다음에 다시 도전하세요.");
        }
    }
}
