package oneminutequiz;

import java.io.IOException;

public class Ch02_2 {
    public static void main(String[] args) throws IOException {
        System.out.print((char)System.in.read());
    }
}
