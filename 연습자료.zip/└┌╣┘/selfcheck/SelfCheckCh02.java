package selfcheck;
import java.util.Scanner;

public class SelfCheckCh02 {
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        System.out.println(scan.nextLine());
        System.out.println(scan.nextLine());
        System.out.println(scan.nextLine());
        scan.close();
    }
}
