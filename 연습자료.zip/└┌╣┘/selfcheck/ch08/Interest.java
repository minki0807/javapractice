package selfcheck.ch08;

public interface Interest {
    void addInterest(); // 이자 계산 메서드
}
