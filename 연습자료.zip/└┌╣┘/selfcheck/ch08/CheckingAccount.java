package selfcheck.ch08;

public class CheckingAccount {
}
